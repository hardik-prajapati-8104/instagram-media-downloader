import Alpine from 'alpinejs';
import { initDownloader } from './downloader';
import { refreshIcons } from './icons';

window.Alpine = Alpine;
Alpine.start();

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-downloader]').forEach(initDownloader);
    refreshIcons();
});
