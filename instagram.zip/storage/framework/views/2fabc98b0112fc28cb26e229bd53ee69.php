<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($meta['title'] ?? config('seo.site_name')); ?></title>
    <meta name="description" content="<?php echo e($meta['description'] ?? ''); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="theme-color" content="#f97316">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?php echo e(config('seo.site_name')); ?>">
    <meta property="og:title" content="<?php echo e($meta['title'] ?? config('seo.site_name')); ?>">
    <meta property="og:description" content="<?php echo e($meta['description'] ?? ''); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta name="twitter:card" content="summary">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lexend+Deca:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-screen bg-white">
<?php
    $nav = [
        ['video', 'Video', 'video'],
        ['reels', 'Reels', 'film'],
        ['photo', 'Photo', 'image'],
        ['carousel', 'Carousel', 'images'],
        ['audio', 'Audio', 'music'],
    ];
?>
<a href="#main" class="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-3 focus:py-2">Skip to content</a>

<header class="sticky top-0 z-40 border-b border-gray-100 bg-white/90 backdrop-blur" x-data="{ open: false }" @keydown.escape.window="open = false">
    <div class="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2.5 font-semibold">
            <span class="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 text-white shadow-md shadow-brand-500/30"><i data-lucide="download" class="h-5 w-5"></i></span>
            <span class="hidden text-[15px] sm:inline">Instagram Media Downloader</span>
            <span class="text-[15px] sm:hidden">IG Downloader</span>
        </a>

        <nav class="hidden items-center gap-1 md:flex" aria-label="Primary">
            <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label, $ico]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route($route)); ?>" class="nav-link" <?php if(request()->routeIs($route)): ?> aria-current="page" <?php endif; ?>>
                    <i data-lucide="<?php echo e($ico); ?>" class="h-4 w-4"></i><?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <button type="button" class="grid h-11 w-11 place-items-center rounded-xl text-gray-700 hover:bg-brand-50 md:hidden" @click="open = !open" :aria-expanded="open" aria-label="Toggle menu">
            <i data-lucide="menu" class="h-6 w-6"></i>
        </button>
    </div>

    <nav x-show="open" x-cloak x-transition.opacity class="border-t border-gray-100 bg-white px-4 py-3 md:hidden" aria-label="Mobile">
        <div class="grid gap-1">
            <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label, $ico]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route($route)); ?>" class="nav-link min-h-11 text-base" <?php if(request()->routeIs($route)): ?> aria-current="page" <?php endif; ?>>
                    <i data-lucide="<?php echo e($ico); ?>" class="h-5 w-5"></i><?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </nav>
</header>

<main id="main">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="mt-24 border-t border-gray-100 bg-brand-50/40">
    <div class="mx-auto max-w-6xl px-4 py-12">
        <?php echo $__env->make('partials.legal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="mt-8 grid gap-8 sm:grid-cols-3">
            <div>
                <p class="font-semibold">Instagram Media Downloader</p>
                <p class="mt-2 text-sm text-gray-500">Independent third-party tool.</p>
            </div>
            <div>
                <p class="text-sm font-semibold">Tools</p>
                <ul class="mt-3 space-y-2 text-sm text-gray-600">
                    <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="hover:text-brand-600" href="<?php echo e(route($route)); ?>">Instagram <?php echo e($label); ?> Downloader</a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div>
                <p class="text-sm font-semibold">Company</p>
                <ul class="mt-3 space-y-2 text-sm text-gray-600">
                    <li><a class="hover:text-brand-600" href="<?php echo e(route('how-to')); ?>">How to download</a></li>
                    <li><a class="hover:text-brand-600" href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                    <li><a class="hover:text-brand-600" href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                    <li><a class="hover:text-brand-600" href="<?php echo e(route('terms')); ?>">Terms</a></li>
                    <li><a class="hover:text-brand-600" href="<?php echo e(route('contact')); ?>">Contact</a></li>
                </ul>
            </div>
        </div>
        <p class="mt-10 text-xs text-gray-400">© <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. Not affiliated with Instagram or Meta.</p>
    </div>
</footer>
</body>
</html>
<?php /**PATH D:\server\www\laravel\instagram\resources\views/layouts/public.blade.php ENDPATH**/ ?>